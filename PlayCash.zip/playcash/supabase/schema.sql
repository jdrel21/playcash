-- PlayCash MVP schema for Supabase PostgreSQL.
-- Run this in Supabase SQL Editor. Never expose the service-role key in the browser.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.offers (
  id text primary key,
  title text not null,
  description text not null default '',
  provider text not null,
  points integer not null check (points > 0),
  active boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  kind text not null check (kind in ('offer_reward','admin_adjustment','withdrawal','reversal')),
  points integer not null check (points <> 0),
  description text not null,
  reference_id text unique,
  created_at timestamptz not null default now()
);
create index if not exists ledger_user_created_idx on public.ledger(user_id, created_at desc);

create table if not exists public.offer_completions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  offer_id text not null references public.offers(id),
  provider_transaction_id text not null unique,
  points integer not null check (points > 0),
  status text not null default 'approved' check (status in ('approved','reversed')),
  created_at timestamptz not null default now()
);

create table if not exists public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  amount_points integer not null check (amount_points >= 10000),
  method text not null check (method in ('paypal','giftcard')),
  destination text not null,
  status text not null default 'pending' check (status in ('pending','approved','paid','rejected','demo_only')),
  admin_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists withdrawals_user_created_idx on public.withdrawal_requests(user_id, created_at desc);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id,email,display_name) values (new.id,new.email,coalesce(new.raw_user_meta_data->>'display_name','')) on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.get_my_balance()
returns bigint language sql stable security definer set search_path = public as $$
  select coalesce(sum(points),0)::bigint from public.ledger where user_id=auth.uid();
$$;
revoke all on function public.get_my_balance() from public;
grant execute on function public.get_my_balance() to authenticated;

-- Atomic withdrawal request: verifies balance, debits ledger, creates request in one transaction.
create or replace function public.request_withdrawal(p_amount_points integer, p_method text, p_destination text)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_user uuid := auth.uid(); v_balance bigint; v_id uuid;
begin
  if v_user is null then raise exception 'Trebuie să fii autentificat.'; end if;
  if p_amount_points is null or p_amount_points < 10000 then raise exception 'Pragul minim este 10.000 puncte.'; end if;
  if p_method not in ('paypal','giftcard') then raise exception 'Metodă de plată invalidă.'; end if;
  if p_destination is null or length(trim(p_destination)) < 3 or length(p_destination) > 200 then raise exception 'Destinație de plată invalidă.'; end if;
  select coalesce(sum(points),0) into v_balance from public.ledger where user_id=v_user;
  if v_balance < p_amount_points then raise exception 'Sold insuficient.'; end if;
  insert into public.withdrawal_requests(user_id,amount_points,method,destination) values(v_user,p_amount_points,p_method,trim(p_destination)) returning id into v_id;
  insert into public.ledger(user_id,kind,points,description,reference_id) values(v_user,'withdrawal',-p_amount_points,'Cerere de retragere în așteptare', 'withdrawal:'||v_id::text);
  return v_id;
end; $$;

alter table public.profiles enable row level security;
alter table public.offers enable row level security;
alter table public.ledger enable row level security;
alter table public.offer_completions enable row level security;
alter table public.withdrawal_requests enable row level security;

drop policy if exists "Users can view own profile" on public.profiles;
create policy "Users can view own profile" on public.profiles for select to authenticated using (id=auth.uid());
drop policy if exists "Users can update own basic profile" on public.profiles;
create policy "Users can update own basic profile" on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());
drop policy if exists "Authenticated users can view active offers" on public.offers;
create policy "Authenticated users can view active offers" on public.offers for select to authenticated using (active=true);
drop policy if exists "Users can view own ledger" on public.ledger;
create policy "Users can view own ledger" on public.ledger for select to authenticated using (user_id=auth.uid());
drop policy if exists "Users can view own completions" on public.offer_completions;
create policy "Users can view own completions" on public.offer_completions for select to authenticated using (user_id=auth.uid());
drop policy if exists "Users can view own withdrawals" on public.withdrawal_requests;
create policy "Users can view own withdrawals" on public.withdrawal_requests for select to authenticated using (user_id=auth.uid());
-- Intentionally no client insert/update policies for ledger, offer completions, or withdrawal requests.
revoke all on function public.request_withdrawal(integer,text,text) from public;
grant execute on function public.request_withdrawal(integer,text,text) to authenticated;

-- Seed offers are inactive until a real provider is contracted and the postback is configured.
insert into public.offers(id,title,description,provider,points,active) values
('sample-orbit','Orbit Dash','Exemplu; nu este o ofertă plătită reală.','demo',150,false),
('sample-tile','Tile Match','Exemplu; nu este o ofertă plătită reală.','demo',100,false),
('sample-gem','Gem Garden','Exemplu; nu este o ofertă plătită reală.','demo',125,false)
on conflict (id) do nothing;
