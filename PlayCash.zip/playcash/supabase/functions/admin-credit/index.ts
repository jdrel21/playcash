// Optional admin utility. Deploy only if you need it; protect it with a strong secret
// and use it only for audited manual corrections. Do not call from the public client.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
Deno.serve(async (req) => {
  if(req.method!=='POST') return new Response('POST required',{status:405});
  const secret=Deno.env.get('ADMIN_CREDIT_SECRET');
  if(!secret || req.headers.get('x-admin-secret')!==secret) return new Response('Unauthorized',{status:401});
  const b=await req.json().catch(()=>null);
  if(!b || typeof b.user_id!=='string' || !Number.isInteger(b.points) || b.points===0 || typeof b.reference_id!=='string' || typeof b.description!=='string') return new Response('Invalid payload',{status:400});
  const db=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const {error}=await db.from('ledger').insert({user_id:b.user_id,kind:'admin_adjustment',points:b.points,reference_id:`admin:${b.reference_id}`,description:b.description});
  if(error)return new Response(JSON.stringify({error:error.message}),{status:400,headers:{'Content-Type':'application/json'}});
  return new Response(JSON.stringify({ok:true}),{headers:{'Content-Type':'application/json'}});
});
