// Example server-to-server offerwall callback. Adapt parameter names and signature
// validation to the actual provider's documentation before enabling real rewards.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const cors = {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type, x-offerwall-secret','Content-Type':'application/json'};
Deno.serve(async (req) => {
  if(req.method==='OPTIONS') return new Response('ok',{headers:cors});
  if(req.method!=='POST') return new Response(JSON.stringify({error:'POST required'}),{status:405,headers:cors});
  const secret=Deno.env.get('OFFERWALL_SHARED_SECRET');
  if(!secret || req.headers.get('x-offerwall-secret')!==secret) return new Response(JSON.stringify({error:'Unauthorized'}),{status:401,headers:cors});
  let body:any; try{body=await req.json()}catch{return new Response(JSON.stringify({error:'Invalid JSON'}),{status:400,headers:cors})}
  const userId=String(body.user_id||''); const offerId=String(body.offer_id||''); const transactionId=String(body.transaction_id||'');
  if(!userId||!offerId||!transactionId) return new Response(JSON.stringify({error:'Missing user_id, offer_id or transaction_id'}),{status:400,headers:cors});
  const admin=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const {data:offer,error:offerError}=await admin.from('offers').select('id,points,active').eq('id',offerId).eq('active',true).single();
  if(offerError||!offer) return new Response(JSON.stringify({error:'Offer not active'}),{status:404,headers:cors});
  const {data:profile,error:profileError}=await admin.from('profiles').select('id').eq('id',userId).single();
  if(profileError||!profile) return new Response(JSON.stringify({error:'Unknown user'}),{status:404,headers:cors});
  // Unique provider_transaction_id prevents replay/double credit. Service role only.
  const {error:insertError}=await admin.from('offer_completions').insert({user_id:userId,offer_id:offerId,provider_transaction_id:transactionId,points:offer.points,status:'approved'});
  if(insertError) return new Response(JSON.stringify({error:'Transaction already processed or invalid'}),{status:409,headers:cors});
  const {error:ledgerError}=await admin.from('ledger').insert({user_id:userId,kind:'offer_reward',points:offer.points,description:`Recompensă ofertă ${offer.title||offerId}`,reference_id:`offerwall:${transactionId}`});
  if(ledgerError){await admin.from('offer_completions').delete().eq('provider_transaction_id',transactionId);return new Response(JSON.stringify({error:'Could not credit ledger'}),{status:500,headers:cors});}
  return new Response(JSON.stringify({ok:true,credited_points:offer.points}),{status:200,headers:cors});
});
